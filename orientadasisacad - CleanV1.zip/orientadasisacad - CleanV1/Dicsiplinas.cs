﻿using sistemaAcad;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System;

public class Disciplinas
{
    private string caminhoBanco;
    private string nomeBancoDisciplinas;
    private string caminhoDoArquivo;
    private List<Disciplina> bancoDisciplinas;

    public Disciplinas()
    {
        caminhoBanco = ConfigurationManager.AppSettings["caminhoBanco"];
        nomeBancoDisciplinas = ConfigurationManager.AppSettings["nomeBancoDisciplinas"];
        caminhoDoArquivo = Path.Combine(caminhoBanco, nomeBancoDisciplinas);
        bancoDisciplinas = CarregarDisciplinasDoCsv();
    }

    public void Inserir(Disciplina disciplina)
    {
        bancoDisciplinas.Add(disciplina);
        Console.WriteLine("Disciplina inserida com sucesso!");
    }

    public void Alterar(string dissig, Disciplina disciplina)
    {
        foreach (var item in bancoDisciplinas)
        {
            if (item.dissig == dissig)
            {
                item.disid = disciplina.disid;
                item.disnome = disciplina.disnome;
                item.dissig = disciplina.dissig;
                item.disobs = disciplina.disobs;
                item.discancelada = disciplina.discancelada;
                Console.WriteLine("Disciplina alterada com sucesso!");
                break;
            }
        }
    }

    public void Excluir(string dissig)
    {
        var disciplina = bancoDisciplinas.Find(d => d.dissig == dissig);
        if (disciplina != null)
        {
            bancoDisciplinas.Remove(disciplina);
            Console.WriteLine("Disciplina removida com sucesso!");
        }
        else
        {
            Console.WriteLine("Disciplina não encontrada.");
        }
    }

    public void Pesquisar(string dissig)
    {
        var disciplina = bancoDisciplinas.Find(d => d.dissig == dissig);
        if (disciplina != null)
        {
            Console.WriteLine($"{disciplina.disid} - {disciplina.disnome} - {disciplina.dissig} - {disciplina.disobs} - Cancelada: {disciplina.discancelada}");
        }
        else
        {
            Console.WriteLine("Disciplina não encontrada.");
        }
    }

    public void ExibirTodos()
    {
        foreach (var disciplina in bancoDisciplinas)
        {
            Console.WriteLine($"{disciplina.disid} - {disciplina.disnome} - {disciplina.dissig} - {disciplina.disobs} - Cancelada: {disciplina.discancelada}");
        }
    }

    public void SalvarDisciplinasEmCsv()
    {
        try
        {
            using (StreamWriter writer = new StreamWriter(caminhoDoArquivo))
            {
                writer.WriteLine("disid,dnome,dissig,disobs,discancelada");
                foreach (var disciplina in bancoDisciplinas)
                {
                    writer.WriteLine($"{disciplina.disid},{disciplina.disnome},{disciplina.dissig},{disciplina.disobs},{disciplina.discancelada}");
                }
            }
            Console.WriteLine("Disciplinas salvas com sucesso!");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Ocorreu um erro ao salvar as disciplinas: " + ex.Message);
        }
    }

    public List<Disciplina> CarregarDisciplinasDoCsv()
    {
        var disciplinas = new List<Disciplina>();
        try
        {
            if (File.Exists(caminhoDoArquivo))
            {
                using (StreamReader reader = new StreamReader(caminhoDoArquivo))
                {
                    string linha = reader.ReadLine(); 
                    while ((linha = reader.ReadLine()) != null)
                    {
                        var partes = linha.Split(',');
                        if (partes.Length == 5)
                        {
                            int disid = int.Parse(partes[0]);
                            string dnome = partes[1];
                            string dissig = partes[2];
                            string disobs = partes[3];
                            string discancelada = partes[4].Trim(); 
                            disciplinas.Add(new Disciplina { disid = disid, disnome = dnome, dissig = dissig, disobs = disobs, discancelada = discancelada });
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Ocorreu um erro ao carregar as disciplinas: " + ex.Message);
        }

        return disciplinas; 
    } 

} 
