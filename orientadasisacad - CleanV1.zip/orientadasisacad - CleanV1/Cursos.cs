﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;

namespace sistemaAcad
{
    internal class Cursos
    {
        private List<Curso> bancoCursos = new List<Curso>();
        private string caminhoBanco;
        private string nomeBancoCursos;
        private string caminhoDoArquivo;

        public Cursos()
        {
            caminhoBanco = ConfigurationManager.AppSettings["caminhoBanco"];
            nomeBancoCursos = ConfigurationManager.AppSettings["nomeBancoCursos"];
            caminhoDoArquivo = Path.Combine(caminhoBanco, nomeBancoCursos);
            bancoCursos = CarregarCursosDoCsv();
        }

        public void Inserir(Curso curso)
        {
            bancoCursos.Add(curso);
            Console.WriteLine("Curso inserido com sucesso!");
        }

        public void Alterar(string cursosig, Curso curso)
        {
            foreach (var item in bancoCursos)
            {
                if (item.cursosig == cursosig)
                {
                    item.cursoid = curso.cursoid;
                    item.cursonome = curso.cursonome;
                    item.cursosig = curso.cursosig;
                    Console.WriteLine("Curso alterado com sucesso!");
                    break;
                }
            }
        }

        public void Excluir(string cursosig)
        {
            var curso = bancoCursos.Find(c => c.cursosig == cursosig);
            if (curso != null)
            {
                bancoCursos.Remove(curso);
                Console.WriteLine("Curso removido com sucesso!");
            }
            else
            {
                Console.WriteLine("Curso não encontrado.");
            }
        }

        public void Pesquisar(string cursosig)
        {
            var curso = bancoCursos.Find(c => c.cursosig == cursosig);
            if (curso != null)
            {
                Console.WriteLine($"{curso.cursoid} - {curso.cursonome} - {curso.cursosig}");
            }
            else
            {
                Console.WriteLine("Curso não encontrado.");
            }
        }

        public void ExibirTodos()
        {
            foreach (var curso in bancoCursos)
            {
                Console.WriteLine($"{curso.cursoid} - {curso.cursonome} - {curso.cursosig}");
            }
        }

        public void SalvarCursosEmCsv()
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(caminhoDoArquivo))
                {
                    writer.WriteLine("codigo,nome,sigla");
                    foreach (var curso in bancoCursos)
                    {
                        writer.WriteLine($"{curso.cursoid},{curso.cursonome},{curso.cursosig}");
                    }
                }
                Console.WriteLine("Cursos salvos com sucesso!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocorreu um erro ao salvar o curso: " + ex.Message);
            }
        }

        public List<Curso> CarregarCursosDoCsv()
        {
            var cursos = new List<Curso>();
            try
            {
                if (File.Exists(caminhoDoArquivo))
                {
                    using (StreamReader reader = new StreamReader(caminhoDoArquivo))
                    {
                        string linha = reader.ReadLine(); 
                        while ((linha = reader.ReadLine()) != null)
                        {
                            var partes = linha.Split(',');
                            if (partes.Length == 3)
                            {
                                int cursoid = int.Parse(partes[0]);
                                string cursonome = partes[1];
                                string cursosig = partes[2];
                                cursos.Add(new Curso { cursoid = cursoid, cursonome = cursonome, cursosig = cursosig });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocorreu um erro ao carregar cursos: " + ex.Message);
            }
            return cursos;
        }
    }
}
