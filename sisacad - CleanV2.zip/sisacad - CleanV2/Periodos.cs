﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;

namespace sistemaAcad
{
    internal class Periodos
    {
        private List<Periodo> bancoPeriodos = new List<Periodo>();
        private string caminhoBanco;
        private string nomeBancoPeriodos;
        private string caminhoDoArquivo;

        public Periodos()
        {
            caminhoBanco = ConfigurationManager.AppSettings["caminhoBanco"];
            nomeBancoPeriodos = ConfigurationManager.AppSettings["nomeBancoPeriodos"];
            caminhoDoArquivo = Path.Combine(caminhoBanco, nomeBancoPeriodos);
            bancoPeriodos = CarregarPeriodosDoCsv();
        }

        public void Inserir(Periodo periodo)
        {
            bancoPeriodos.Add(periodo);
            Console.WriteLine("Período inserido com sucesso!");
        }

        public void Alterar(string persigla, Periodo periodo)
        {
            foreach (var item in bancoPeriodos)
            {
                if (item.persigla == persigla)
                {
                    item.perid = periodo.perid;
                    item.pernome = periodo.pernome;
                    item.persigla = periodo.persigla;
                    Console.WriteLine("Período alterado com sucesso!");
                    break;
                }
            }
        }

        public void Excluir(string persigla)
        {
            var periodo = bancoPeriodos.Find(p => p.persigla == persigla);
            if (periodo != null)
            {
                bancoPeriodos.Remove(periodo);
                Console.WriteLine("Período removido com sucesso!");
            }
            else
            {
                Console.WriteLine("Período não encontrado.");
            }
        }

        public void Pesquisar(string persigla)
        {
            var periodo = bancoPeriodos.Find(p => p.persigla == persigla);
            if (periodo != null)
            {
                Console.WriteLine($"{periodo.perid} - {periodo.pernome} - {periodo.persigla}");
            }
            else
            {
                Console.WriteLine("Período não encontrado.");
            }
        }

        public void ExibirTodos()
        {
            foreach (var periodo in bancoPeriodos)
            {
                Console.WriteLine($"{periodo.perid} - {periodo.pernome} - {periodo.persigla}");
            }
        }

        public void SalvarPeriodosEmCsv()
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(caminhoDoArquivo))
                {
                    writer.WriteLine("perid,pernome,persigla");
                    foreach (var periodo in bancoPeriodos)
                    {
                        writer.WriteLine($"{periodo.perid},{periodo.pernome},{periodo.persigla}");
                    }
                }
                Console.WriteLine("Períodos salvos com sucesso!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocorreu um erro ao salvar os períodos: " + ex.Message);
            }
        }

        public List<Periodo> CarregarPeriodosDoCsv()
        {
            var periodos = new List<Periodo>();
            try
            {
                if (File.Exists(caminhoDoArquivo))
                {
                    using (StreamReader reader = new StreamReader(caminhoDoArquivo))
                    {
                        string linha = reader.ReadLine(); // Lê o cabeçalho
                        while ((linha = reader.ReadLine()) != null)
                        {
                            var partes = linha.Split(',');
                            if (partes.Length == 3)
                            {
                                int perid = int.Parse(partes[0]);
                                string pernome = partes[1];
                                string persigla = partes[2];
                                periodos.Add(new Periodo { perid = perid, pernome = pernome, persigla = persigla });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocorreu um erro ao carregar períodos: " + ex.Message);
            }
            return periodos;
        }
    }
}