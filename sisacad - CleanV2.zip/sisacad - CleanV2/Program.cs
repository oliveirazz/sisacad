﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using sistemaAcad;
using System.Reflection;

namespace ssistemaAcad
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int opcao = 0;
            int subopcao = 0;

            string sigla;

            Cursos cursos = new Cursos();
            Curso curso;

            Periodos periodos = new Periodos();
            Periodo periodo;

            Disciplinas disciplinas = new Disciplinas();
            Disciplina disciplina;

            while (opcao != 9)
            {
                Console.WriteLine("Sistema: Escolas e Faculdades");
                Console.WriteLine("1. Periodos");
                Console.WriteLine("2. Cursos");
                Console.WriteLine("3. Disciplinas");
                Console.WriteLine("9. Sair");
                Console.Write("Digite a opcao: ");
                opcao = int.Parse(Console.ReadLine());

                if (opcao == 1)
                {
                    subopcao = 0;

                    while (subopcao != 19)
                    {
                        Console.WriteLine("10. Inserir");
                        Console.WriteLine("11. Alterar");
                        Console.WriteLine("12. Excluir");
                        Console.WriteLine("13. Pesquisar");
                        Console.WriteLine("14. Exibir");
                        Console.WriteLine("15. Salvar banco");
                        Console.WriteLine("19. Sair");
                        Console.Write("Digite a subopcao: ");
                        subopcao = int.Parse(Console.ReadLine());

                        if (subopcao == 10)
                        {
                            periodo = new Periodo();
                            Console.Write("Digite o ID do período: ");
                            periodo.perid = int.Parse(Console.ReadLine());
                            Console.Write("Digite o nome do período: ");
                            periodo.pernome = Console.ReadLine();
                            Console.Write("Digite a sigla do período: ");
                            periodo.persigla = Console.ReadLine();

                            periodos.Inserir(periodo);
                        }
                        else if (subopcao == 11)
                        {
                            Console.Write("Digite a sigla do período a ser alterado: ");
                            sigla = Console.ReadLine();

                            periodo = new Periodo();
                            Console.Write("Digite a nova sigla: ");
                            periodo.persigla = Console.ReadLine();
                            Console.Write("Digite o novo nome: ");
                            periodo.pernome = Console.ReadLine();
                            periodos.Alterar(sigla, periodo);
                        }
                        else if (subopcao == 12)
                        {
                            Console.Write("Digite a sigla do período a ser excluído: ");
                            sigla = Console.ReadLine();
                            periodos.Excluir(sigla);
                        }
                        else if (subopcao == 13)
                        {
                            Console.Write("Digite a sigla do período para pesquisa: ");
                            sigla = Console.ReadLine();
                            periodos.Pesquisar(sigla);
                        }
                        else if (subopcao == 14)
                        {
                            periodos.ExibirTodos();
                        }
                        else if (subopcao == 15)
                        {
                            periodos.SalvarPeriodosEmCsv();
                        }
                    }
                }

                if (opcao == 2)
                {
                    subopcao = 0;

                    while (subopcao != 29)
                    {
                        Console.WriteLine("20. Inserir");
                        Console.WriteLine("21. Alterar");
                        Console.WriteLine("22. Excluir");
                        Console.WriteLine("23. Pesquisar");
                        Console.WriteLine("24. Exibir");
                        Console.WriteLine("25. Salvar em Banco");
                        Console.WriteLine("29. Sair");
                        Console.Write("Digite a subopcao: ");
                        subopcao = int.Parse(Console.ReadLine());

                        if (subopcao == 20)
                        {
                            curso = new Curso();
                            Console.Write("Digite o ID do curso: ");
                            curso.cursoid = int.Parse(Console.ReadLine());
                            Console.Write("Digite o nome do curso: ");
                            curso.cursonome = Console.ReadLine();
                            Console.Write("Digite a sigla do curso: ");
                            curso.cursosig = Console.ReadLine();
                            Console.Write("Digite as observações do curso: ");
                            curso.cursoobs = Console.ReadLine();

                            cursos.Inserir(curso);
                        }
                        else if (subopcao == 21)
                        {
                            Console.Write("Digite a sigla do curso a ser alterado: ");
                            sigla = Console.ReadLine();
                            curso = new Curso();
                            Console.Write("Digite a nova sigla: ");
                            curso.cursosig = Console.ReadLine();
                            Console.Write("Digite o novo nome: ");
                            curso.cursonome = Console.ReadLine();
                            Console.Write("Digite as novas observações: ");
                            curso.cursoobs = Console.ReadLine();

                            cursos.Alterar(sigla, curso);
                        }
                        else if (subopcao == 22)
                        {
                            Console.Write("Digite a sigla do curso a ser excluído: ");
                            sigla = Console.ReadLine();
                            cursos.Excluir(sigla);
                        }
                        else if (subopcao == 23)
                        {
                            Console.Write("Digite a sigla do curso para pesquisa: ");
                            sigla = Console.ReadLine();
                            cursos.Pesquisar(sigla);
                        }
                        else if (subopcao == 24)
                        {
                            cursos.ExibirTodos();
                        }
                        else if (subopcao == 25)
                        {
                            cursos.SalvarCursosEmCsv();
                        }
                    }
                }

                if (opcao == 3)
                {
                    subopcao = 0;

                    while (subopcao != 39)
                    {
                        Console.WriteLine("30. Inserir");
                        Console.WriteLine("31. Alterar");
                        Console.WriteLine("32. Excluir");
                        Console.WriteLine("33. Pesquisar");
                        Console.WriteLine("34. Exibir");
                        Console.WriteLine("35. Salvar banco");
                        Console.WriteLine("39. Sair");
                        Console.Write("Digite a subopcao: ");
                        subopcao = int.Parse(Console.ReadLine());

                        if (subopcao == 30)
                        {
                            disciplina = new Disciplina();
                            Console.Write("Digite o ID da disciplina: ");
                            disciplina.disid = int.Parse(Console.ReadLine());
                            Console.Write("Digite o nome da disciplina: ");
                            disciplina.disnome = Console.ReadLine();
                            Console.Write("Digite a sigla da disciplina: ");
                            disciplina.dissig = Console.ReadLine();
                            Console.Write("Digite as observações da disciplina: ");
                            disciplina.disobs = Console.ReadLine();

                            disciplinas.Inserir(disciplina);
                        }
                        else if (subopcao == 31)
                        {
                            Console.Write("Digite a sigla da disciplina a ser alterada: ");
                            sigla = Console.ReadLine();
                            disciplina = new Disciplina();
                            Console.Write("Digite a nova sigla: ");
                            disciplina.dissig = Console.ReadLine();
                            Console.Write("Digite o novo nome: ");
                            disciplina.disnome = Console.ReadLine();
                            Console.Write("Digite as novas observações: ");
                            disciplina.disobs = Console.ReadLine();

                            disciplinas.Alterar(sigla, disciplina);
                        }
                        else if (subopcao == 32)
                        {
                            Console.Write("Digite a sigla da disciplina a ser excluída: ");
                            sigla = Console.ReadLine();
                            disciplinas.Excluir(sigla);
                        }
                        else if (subopcao == 33)
                        {
                            Console.Write("Digite a sigla da disciplina para pesquisa: ");
                            sigla = Console.ReadLine();
                            disciplinas.Pesquisar(sigla);
                        }
                        else if (subopcao == 34)
                        {
                            disciplinas.ExibirTodos();
                        }
                        else if (subopcao == 35)
                        {
                            disciplinas.SalvarDisciplinasEmCsv();
                        }
                    }
                }
            }
        }
    }
}
