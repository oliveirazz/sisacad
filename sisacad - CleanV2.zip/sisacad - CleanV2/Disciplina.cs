﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistemaAcad
{
    public class Disciplina
    {
        public int disid { get; set; }
        public string disnome { get; set; }
        public string dissig { get; set; }
        public string disobs { get; set; }
        public string discancelada { get; set; } 
    }
}
