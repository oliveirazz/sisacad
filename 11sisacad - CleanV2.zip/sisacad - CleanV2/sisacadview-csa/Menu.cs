﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using sisacadmodel;
using sisacadcontroller;

namespace sisacadview_csa
{
    public class Menu
    {
        private Cursos cursos = new Cursos();
        private Curso curso;

        private void exibirSubMenuCursos()
        {
            subopcao = 0;

            while (subopcao != 19)
            {
                Console.WriteLine("10. Inserir");
                Console.WriteLine("11. Alterar");
                Console.WriteLine("12. Excluir");
                Console.WriteLine("13. Pesquisar");
                Console.WriteLine("14. Exibir");
                Console.WriteLine("15. Salvar banco");
                Console.WriteLine("19. Sair");
                Console.Write("Digite a subopcao: ");
                subopcao = int.Parse(Console.ReadLine());

                if (subopcao == 10)
                {
                    periodo = new Periodo();
                    Console.Write("Digite o ID do período: ");
                    periodo.perid = int.Parse(Console.ReadLine());
                    Console.Write("Digite o nome do período: ");
                    periodo.pernome = Console.ReadLine();
                    Console.Write("Digite a sigla do período: ");
                    periodo.persigla = Console.ReadLine();

                    periodos.Inserir(periodo);
                }
                else if (subopcao == 11)
                {
                    Console.Write("Digite a sigla do período a ser alterado: ");
                    sigla = Console.ReadLine();

                    periodo = new Periodo();
                    Console.Write("Digite a nova sigla: ");
                    periodo.persigla = Console.ReadLine();
                    Console.Write("Digite o novo nome: ");
                    periodo.pernome = Console.ReadLine();
                    periodos.Alterar(sigla, periodo);
                }
                else if (subopcao == 12)
                {
                    Console.Write("Digite a sigla do período a ser excluído: ");
                    sigla = Console.ReadLine();
                    periodos.Excluir(sigla);
                }
                else if (subopcao == 13)
                {
                    Console.Write("Digite a sigla do período para pesquisa: ");
                    sigla = Console.ReadLine();
                    periodos.Pesquisar(sigla);
                }
                else if (subopcao == 14)
                {
                    periodos.ExibirTodos();
                }
                else if (subopcao == 15)
                {
                    periodos.SalvarPeriodosEmCsv();
                }
            }
        }
        public void exibir()
        {
            int opcao = 0;
            while (opcao != 9)
            {
                Console.WriteLine("Sistema: Escolas e Faculdades");
                Console.WriteLine("1. Periodos");
                Console.WriteLine("2. Cursos");
                Console.WriteLine("3. Disciplinas");
                Console.WriteLine("9. Sair");
                Console.Write("Digite a opcao: ");
                opcao = int.Parse(Console.ReadLine());

                if (opcao == 1)
                {
                    exibirSubMenuCursos();
                }

                else if (opcao == 2)
                {

                }

                else if (opcao == 3)
                {

                }


            }
        }
    }
}
