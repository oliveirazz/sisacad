﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sisacadmodel
{
    public class Periodo
    {
        public int perid { get; set; }

        public string pernome { get; set; }

        public string persigla { get; set; }
    }    
}
