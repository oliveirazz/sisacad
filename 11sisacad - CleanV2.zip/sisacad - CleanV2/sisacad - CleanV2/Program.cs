﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Configuration;
using sistemaAcad;
using System.Reflection;

using sisacadview_csa;



namespace ssistemaAcad
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Menu menu = new Menu();
            menu.exibir();
        }
    }
}
