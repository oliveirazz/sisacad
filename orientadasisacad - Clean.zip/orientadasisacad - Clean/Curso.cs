﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistemaAcad
{
    internal class Curso
    {
        public int cursoid { get; set; }

        public string cursonome { get; set; }

        public string cursosig { get; set; }

        public string cursoobs { get; set; }
    }
}
